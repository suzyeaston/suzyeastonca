param(
    [string]$RepoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path,
    [switch]$IncludeBusinessLicences,
    [switch]$SkipOverpass,
    [switch]$SkipReferenceRefresh,
    [switch]$SkipWorldBuild,
    [switch]$UseCustomImportsOnly,
    [int]$FilterRadiusMeters = 400,
    [int]$RoutePaddingMeters = 120,
    [string]$OverpassUserAgent = "SuzyGastownSim/0.1 (local build pipeline)",
    [string]$OverpassEndpoint = "https://overpass-api.de/api/interpreter",
    [int]$OverpassTimeoutSeconds = 90
)

$ErrorActionPreference = 'Stop'

function Write-Step {
    param([string]$Message)
    Write-Host "`n=== $Message ===" -ForegroundColor Cyan
}

function Assert-Command {
    param([string]$Name)
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "Required command not found: $Name"
    }
}

Write-Step "Gastown scene cache pipeline"
Write-Host "Repo root: $RepoRoot"

Assert-Command -Name node

Push-Location $RepoRoot
try {
    $covDir = Join-Path $RepoRoot 'data/cov'
    $osmDir = Join-Path $RepoRoot 'data/osm'
    $referenceRefreshDir = Join-Path $RepoRoot 'data/reference/refresh'

    New-Item -ItemType Directory -Force -Path $covDir | Out-Null
    New-Item -ItemType Directory -Force -Path $osmDir | Out-Null
    New-Item -ItemType Directory -Force -Path $referenceRefreshDir | Out-Null

    if (-not $UseCustomImportsOnly) {
        Write-Step "Pulling City of Vancouver open data"
        $env:COV_FILTER_RADIUS_METERS = "$FilterRadiusMeters"
        $env:COV_ROUTE_PADDING_METERS = "$RoutePaddingMeters"
        if ($IncludeBusinessLicences) {
            $env:COV_INCLUDE_BUSINESS_LICENCES = 'true'
        }
        else {
            Remove-Item Env:COV_INCLUDE_BUSINESS_LICENCES -ErrorAction SilentlyContinue
        }

        & node (Join-Path 'scripts' 'sync-cov-open-data.js')
        if ($LASTEXITCODE -ne 0) {
            throw "City of Vancouver sync failed."
        }
    }
    else {
        Write-Step "Skipping CoV pull because -UseCustomImportsOnly was supplied"
    }

    if (-not $SkipReferenceRefresh) {
        Write-Step "Refreshing lightweight local reference files"
        & powershell -ExecutionPolicy Bypass -File (Join-Path 'scripts' 'refresh-gastown-reference-data.ps1')
        if ($LASTEXITCODE -ne 0) {
            throw "Reference refresh failed."
        }
    }
    else {
        Write-Step "Skipping reference refresh"
    }

    if (-not $SkipOverpass) {
        Write-Step "Pulling OSM / Overpass context"
        & powershell -ExecutionPolicy Bypass -File (Join-Path 'scripts' 'export-gastown-overpass.ps1') `
            -RepoRoot $RepoRoot `
            -UserAgent $OverpassUserAgent `
            -Endpoint $OverpassEndpoint `
            -TimeoutSeconds $OverpassTimeoutSeconds
        if ($LASTEXITCODE -ne 0) {
            throw "Overpass export failed."
        }
    }
    else {
        Write-Step "Skipping Overpass context pull"
    }

    if (-not $SkipWorldBuild) {
        Write-Step "Building runtime world JSON"
        & node (Join-Path 'scripts' 'build-gastown-world.js')
        if ($LASTEXITCODE -ne 0) {
            throw "World build failed."
        }
    }
    else {
        Write-Step "Skipping world build"
    }

    Write-Step "Done"
    Write-Host "Key outputs:" -ForegroundColor Green
    Write-Host " - data/cov/*.geojson"
    Write-Host " - data/reference/refresh/*.geojson"
    Write-Host " - data/osm/gastown-overpass.json"
    Write-Host " - data/osm/gastown-pois.geojson"
    Write-Host " - assets/world/gastown-water-street.json"
}
finally {
    Pop-Location
}
